# Monster Empire Android

Projet Android minimal utilisant une WebView et un jeu HTML local hors-ligne.

## Compilation
- Java 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1

Lancer `gradle assembleDebug`. L'APK debug est généré dans `app/build/outputs/apk/debug/app-debug.apk`.

Le workflow GitHub Actions construit automatiquement l'APK à chaque push sur `main` ou via `workflow_dispatch`.
